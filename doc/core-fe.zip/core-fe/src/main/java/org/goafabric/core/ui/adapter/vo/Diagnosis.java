package org.goafabric.core.ui.adapter.vo;

public record Diagnosis (
    String id,
    String code,
    String display,
    String shortname
) {}
