package org.goafabric.core.medicalrecords.repository.entity;

import jakarta.persistence.*;
import org.goafabric.core.organization.repository.extensions.AuditTrailListener;
import org.hibernate.annotations.BatchSize;

import java.util.List;


@Entity
@Table(name="medical_container")
@EntityListeners(AuditTrailListener.class)
public class MedicalContainerEo {
    @Id
    @GeneratedValue(strategy = GenerationType.UUID)
    public String id;

    @OneToMany(cascade = CascadeType.ALL)
    @JoinColumn(name = "medical_container_id")
    @BatchSize(size = 100)
    public List<MedicalRecordEo> medicalRecords;

    @Version //optimistic locking
    public Long version;

}
