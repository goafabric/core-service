package org.goafabric.core.medicalrecords.repository.entity;

import jakarta.persistence.*;
import org.hibernate.annotations.BatchSize;
import org.hibernate.annotations.TenantId;

import java.time.LocalDate;
import java.util.List;

@Entity
@Table(name = "encounter")
public class EncounterEo {

    @Id
    @GeneratedValue(strategy = GenerationType.UUID)
    public String id;

    @TenantId
    public String orgunitId;

    public String patientId;

    public String practitionerId;

    public LocalDate encounterDate;

    public String encounterName;

    @OneToMany(cascade = CascadeType.ALL)
    @JoinColumn(name = "encounter_id")
    @BatchSize(size = 100)
    public List<MedicalContainerEo> medicalContainers;

    @Version //optimistic locking
    public Long version;

}
