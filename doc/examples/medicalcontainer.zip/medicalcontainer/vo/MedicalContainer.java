package org.goafabric.core.medicalrecords.controller.vo;

import java.util.Collections;
import java.util.List;

public record MedicalContainer(
    String id,
    String version,
    List<MedicalRecord> medicalRecords
) {
    public MedicalContainer(String id, String version, MedicalRecord medicalRecord) {
        this(id, version, Collections.singletonList(medicalRecord));
    }
}
