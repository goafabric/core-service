package org.goafabric.core.medicalrecords.repository;

import org.goafabric.core.medicalrecords.repository.entity.EncounterEo;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;

import java.util.List;

public interface EncounterRepository extends CrudRepository<EncounterEo, String> {

    @Query("SELECT e FROM EncounterEo e JOIN FETCH e.medicalContainers c JOIN c.medicalRecords m WHERE e.patientId = :patientId AND UPPER(m.display) LIKE UPPER(concat('%', :display, '%'))")
    List<EncounterEo> findByPatientIdAndMedicalContainers_MedicalRecords_DisplayContainsIgnoreCase(String patientId, String display);

}

